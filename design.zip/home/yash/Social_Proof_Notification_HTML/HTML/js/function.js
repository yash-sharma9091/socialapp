$(document).ready(function() {
						   
	$("body").click(function(e) {
		$(".dropdwn > .dropdwnMenu").slideUp("fast");
		$(".dropdwn > .dropdwnMenu").removeClass("activeSelectMenu");
	});
	
	$(".dropdwn > .dropdownClick").click(function(e){
		e.stopPropagation();
		$(this).siblings(".dropdwnMenu").slideToggle("fast");
		$(this).siblings(".dropdwnMenu").toggleClass("activeDropdwn");
							
	});
	
	
	
	 
	
	$('.bannerSlider').owlCarousel({
		items: 1,
		loop: true,
		margin: 0,
		autoplay:true,
    	autoplayTimeout:2500,
    	autoplayHoverPause:true,
		nav: false,
		dots: true
	});
	
	 
	
	$(document).click(function(){
		$(".videWrapr").hide();				   
	});
	
	$("#scrolDwn1").click(function() {
		$('html, body').animate({
			scrollTop: $(".trialSection").offset().top
		}, 700);
	});
	
	
});